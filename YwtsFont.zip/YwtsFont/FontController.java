package com.example.daalgawruud;

import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

import java.util.List;

public class FontController {
    static ObservableList<String>  fNames = FXCollections.observableArrayList(Font.getFamilies());
    static ObservableList<String> fStyle = FXCollections.observableArrayList("Regular", "Italic", "Bold", "Bold Italic");

    static ObservableList<String> fSize = FXCollections.observableArrayList("8", "10",  "12", "14", "16", "18", "24", "36");
    String value1, value2, value3,value5;
    boolean value4;
    int a;


    @FXML
    private ColorPicker colorChoose;

    @FXML
    private ListView<String> fontList;


    @FXML
    private TextField style;

    @FXML
    private Button Btn;

    @FXML
    private Label sampleText;

    @FXML
    private ListView<String> sizeList;

    @FXML
    private TextField font;

    @FXML
    private ListView<String> styleList;

    @FXML
    private TextField size;

    @FXML
    private CheckBox UndChecBox;

    @FXML
    void Btnclose(ActionEvent event) {
        Platform.exit();
    }

    @FXML
    void colorEvent(ActionEvent event) {
        value5 = "#" + Integer.toHexString(colorChoose.getValue().hashCode());
        sampleText.setStyle("-fx-text-color: " + value5 + ";");
    }
    @FXML
    void underCheck(ActionEvent event) {
         if(UndChecBox.isSelected()){
            value4=true;
         }
         else value4 = false;
        sampleText.setUnderline(value4);
    }
    @FXML
    void initialize() {
        fontList.setItems(fNames);
        styleList.setItems(fStyle);
        sizeList.setItems(fSize);
        fontList.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observableValue, String s, String t1) {
                font.setText(t1);
                value1 = t1;
                sampleText.setFont(Font.font(t1, FontWeight.NORMAL,12));
            }
        });
        styleList.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observableValue, String s, String t1) {
                style.setText(t1);
                value2=t1;
                if (value2.equals("Bold")){
                    sampleText.setFont(Font.font(value1, FontWeight.BOLD, 12));
                } else if (value2.equals("Bold Italic")) {
                    sampleText.setFont(Font.font(value1,FontWeight.BOLD, FontPosture.ITALIC,12));
                } else if (value2.equals("Italic")) {
                    sampleText.setFont(Font.font(value1, FontPosture.ITALIC,12));
                }
                else{
                    sampleText.setFont(Font.font(value1,FontWeight.NORMAL,12));
                }
            }
        });
        sizeList.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> observableValue, String s, String t1) {
                size.setText(t1);
                value3=sizeList.getSelectionModel().getSelectedItem();
                a=Integer.parseInt(value3);
                if (value2.equals("Bold")){
                    sampleText.setFont(Font.font(value1,FontWeight.BOLD,a));
                } else if (value2.equals("Bold Italic")) {
                    sampleText.setFont(Font.font(value1,FontWeight.BOLD, FontPosture.ITALIC,a));
                } else if (value2.equals("Italic")) {
                    sampleText.setFont(Font.font(value1, FontPosture.ITALIC,a));
                }
                else{
                    sampleText.setFont(Font.font(value1,FontWeight.NORMAL,a));
                }
            }
        });
    }
}
