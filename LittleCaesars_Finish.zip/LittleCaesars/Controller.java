package com.example.daalgawruud;
import javafx.application.Platform;
import javafx.beans.binding.Bindings;
import javafx.beans.binding.IntegerBinding;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.ObservableSet;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.paint.Color;
import java.text.DecimalFormat;
import java.util.Optional;

public class Controller {
    ObservableList<Integer> listNumber = FXCollections.observableArrayList(0,1,2,3,4,5,6);

    @FXML
    private ToggleGroup Toggle;

    @FXML
    private ComboBox<Integer> beerBox;

    @FXML
    private TextField bevCalc;

    @FXML
    private Button calc;

    @FXML
    private Button check;

    @FXML
    private Button clear;

    @FXML
    private ComboBox<Integer> cokeBox;

    @FXML
    private TextField delTxt;

    @FXML
    private Button exit;

    @FXML
    private TextField gtotalTxt;

    @FXML
    private TextField hstTxt;

    @FXML
    private RadioButton large;

    @FXML
    private RadioButton medium;

    @FXML
    private ComboBox<Integer> orangeBox;

    @FXML
    private RadioButton party;

    @FXML
    private TextField sizeCalc;

    @FXML
    private RadioButton small;

    @FXML
    private ComboBox<Integer> spriteBox;

    @FXML
    private TextField subtotalTxt;

    @FXML
    private CheckBox topBac;

    @FXML
    private TextField topCalc;

    @FXML
    private CheckBox topExtraChe;

    @FXML
    private CheckBox topGrPep;

    @FXML
    private CheckBox topHotPep;

    @FXML
    private CheckBox topMush;

    @FXML
    private CheckBox topOni;

    @FXML
    private CheckBox topPep;

    @FXML
    private CheckBox topToma;

    @FXML
    void setCalc(ActionEvent event) {
        subTotal = sizeCash + topCash + bevCash;
        subtotalTxt.setText("$" + df.format(subTotal));
        if (subTotal >= 15) {
            delFee = 0.00;
            delTxt.setBackground(Background.fill(Color.GREEN));
        } else {
            delFee = 5.00;
            delTxt.setBackground(subtotalTxt.getBackground());
        }
        delTxt.setText("$" + df.format(delFee));

        hst = (subTotal + delFee) * 0.1;
        hstTxt.setText("$" + df.format(hst));

        grandTotal = subTotal + delFee + hst;
        gtotalTxt.setText("$" + df.format(grandTotal));
    }

    @FXML
    void setClear() {
        small.setSelected(false);
        medium.setSelected(false);
        large.setSelected(false);
        party.setSelected(false);

        topMush.setSelected(false);
        topGrPep.setSelected(false);
        topOni.setSelected(false);
        topHotPep.setSelected(false);
        topPep.setSelected(false);
        topBac.setSelected(false);
        topToma.setSelected(false);
        topExtraChe.setSelected(false);

        cokeBox.setValue(0);
        spriteBox.setValue(0);
        orangeBox.setValue(0);
        beerBox.setValue(0);

        sizeCalc.setText("$0.00");
        topCalc.setText("$0.00");
        bevCalc.setText("$0.00");

        subtotalTxt.setText("$0.00");
        delTxt.setText("$0.00");
        delTxt.setBackground(subtotalTxt.getBackground());
        hstTxt.setText("$0.00");
        gtotalTxt.setText("$0.00");

        sizeCash = topCash = bevCash = 0;
        subTotal = delFee = hst = grandTotal = 0;
    }

    @FXML
    void setExit(ActionEvent event) {
        // Platform.exit();
        Alert closeAlert = new Alert(Alert.AlertType.CONFIRMATION, "", ButtonType.YES, ButtonType.NO);
        closeAlert.setHeaderText("Are you sure you want to exit?");


        Optional<ButtonType> confirm = closeAlert.showAndWait();

        if (confirm.isPresent() && confirm.get() == ButtonType.YES) {
            Alert closeInfo = new Alert(Alert.AlertType.INFORMATION, "", ButtonType.OK);
            closeInfo.setHeaderText("Thank you for choosing Little Caesars!");

            Optional<ButtonType> close =closeInfo.showAndWait();
            if(close.isPresent() && close.get() == ButtonType.OK)
                Platform.exit();
        }
        if (confirm.isPresent() && confirm.get() == ButtonType.NO) {
            closeAlert.close();
        }

    }

    @FXML
    void setCheck(ActionEvent event) {
        if(!small.isSelected() && !medium.isSelected() && !large.isSelected() && !party.isSelected())
        {
            Alert noneSelectPizza = new Alert(Alert.AlertType.ERROR, "", ButtonType.OK);
            noneSelectPizza.setTitle("Incomplete order");
            noneSelectPizza.setHeaderText("Your order could not be completed!\n" +
                    "Please select a pizza size.");
            Optional<ButtonType> close = noneSelectPizza.showAndWait();
            if(close.isPresent() && close.get() == ButtonType.OK)
                noneSelectPizza.close();
        }
        else {
            Alert order = new Alert(Alert.AlertType.CONFIRMATION, "", ButtonType.YES, ButtonType.NO);
            order.setTitle("Order Summary");
            order.setHeaderText("Is this order correct?");
            //ORDER
            order.setContentText("PIZZA:\n" + size() +
                    "\nTOPPINGS:\n" + toppings() +
                    "\nBEVERAGES:\n" + beverages());
            //

            Optional<ButtonType> orderConf = order.showAndWait();

            if (orderConf.isPresent() && orderConf.get() == ButtonType.YES)
            {
                order.close();
                Alert closeInfo = new Alert(Alert.AlertType.INFORMATION, "", ButtonType.OK);

                ImageView icon = new ImageView(this.getClass().getResource("Little.png").toString());
                icon.setFitHeight(52);
                icon.setFitWidth(52);
                closeInfo.setGraphic(icon);

                closeInfo.setHeaderText("Thank you for ordering from Little Caesars!\n" +
                        "Your pizza will be delivered in 30 minutes or it's free!");

                Optional<ButtonType> close = closeInfo.showAndWait();
                if (close.isPresent() && close.get() == ButtonType.OK) {
                    setClear();
                    order.close();
                }
            }
            if (orderConf.isPresent() && orderConf.get() == ButtonType.NO) {
                order.close();
            }
        }


    }
    DecimalFormat df = new DecimalFormat("0.00");
    private double sizeCash = 0.00, topCash = 0.00, bevCash = 0.00;
    double subTotal = 0.00, delFee = 0.00, hst = 0.00, grandTotal = 0.00;
    private int temp1 = 0, temp2 = 0, temp3 = 0, temp4 = 0, tempTop = 0;
    private ObservableSet<CheckBox> selectedCheck = FXCollections.observableSet();
    private IntegerBinding numCheck = Bindings.size(selectedCheck);

    @FXML
    private void initialize()
    {
        cokeBox.setItems(listNumber);
        spriteBox.setItems(listNumber);
        orangeBox.setItems(listNumber);
        beerBox.setItems(listNumber);

        Toggle.selectedToggleProperty().addListener(event -> {
                    if (small.isSelected()) {
                        sizeCash = 7.99;
                    } else if (medium.isSelected()) {
                        sizeCash = 8.99;
                    } else if (large.isSelected()) {
                        sizeCash = 9.99;
                    } else {
                        sizeCash = 10.99;
                    }
                    sizeCalc.setText("$" + df.format(sizeCash));
                }
        );

        cokeBox.setOnAction(actionEvent -> {
                    if (cokeBox.getValue() != null) temp1 = cokeBox.getValue();
                    if (spriteBox.getValue() != null) temp2 = spriteBox.getValue();
                    if (orangeBox.getValue() != null) temp3 = orangeBox.getValue();
                    if (beerBox.getValue() != null) temp4 = beerBox.getValue();
                    bevCash = temp1 + temp2 + temp3 + temp4;
                    bevCash *= 0.99;
                    bevCalc.setText("$" + df.format(bevCash));
                    temp1 = temp2 = temp3 = temp4 = 0;
                }
        );
        spriteBox.setOnAction(actionEvent -> {
                    if (cokeBox.getValue() != null) temp1 = cokeBox.getValue();
                    if (spriteBox.getValue() != null) temp2 = spriteBox.getValue();
                    if (orangeBox.getValue() != null) temp3 = orangeBox.getValue();
                    if (beerBox.getValue() != null) temp4 = beerBox.getValue();
                    bevCash = temp1 + temp2 + temp3 + temp4;
                    bevCash *= 0.99;
                    bevCalc.setText("$" + df.format(bevCash));
                    temp1 = temp2 = temp3 = temp4 = 0;
                }
        );
        orangeBox.setOnAction(actionEvent -> {
                    if (cokeBox.getValue() != null) temp1 = cokeBox.getValue();
                    if (spriteBox.getValue() != null) temp2 = spriteBox.getValue();
                    if (orangeBox.getValue() != null) temp3 = orangeBox.getValue();
                    if (beerBox.getValue() != null) temp4 = beerBox.getValue();
                    bevCash = temp1 + temp2 + temp3 + temp4;
                    bevCash *= 0.99;
                    bevCalc.setText("$" + df.format(bevCash));
                    temp1 = temp2 = temp3 = temp4 = 0;
                }
        );
        beerBox.setOnAction(actionEvent -> {
                    if (cokeBox.getValue() != null) temp1 = cokeBox.getValue();
                    if (spriteBox.getValue() != null) temp2 = spriteBox.getValue();
                    if (orangeBox.getValue() != null) temp3 = orangeBox.getValue();
                    if (beerBox.getValue() != null) temp4 = beerBox.getValue();
                    bevCash = temp1 + temp2 + temp3 + temp4;
                    bevCash *= 0.99;
                    bevCalc.setText("$" + df.format(bevCash));
                    temp1 = temp2 = temp3 = temp4 = 0;
                }
        );
        confCheckBox(topMush);
        confCheckBox(topGrPep);
        confCheckBox(topOni);
        confCheckBox(topHotPep);
        confCheckBox(topPep);
        confCheckBox(topBac);
        confCheckBox(topToma);
        confCheckBox(topExtraChe);

        numCheck.addListener((obs, oldSelectedCount, newSelectedCount) -> {
            if (newSelectedCount.intValue() < 3) {
                topCash = 0.00;
            } else {
                topCash = newSelectedCount.intValue() - 3.00;
            }
            topCalc.setText("$" + df.format(topCash));
        });
    }
    private void confCheckBox(CheckBox checkBox)
    {
        if (checkBox.isSelected()) {
            selectedCheck.add(checkBox);
        }
        checkBox.selectedProperty().addListener((obs, wasSelected, isNowSelected) -> {
            if (isNowSelected) {
                selectedCheck.add(checkBox);
            } else {
                selectedCheck.remove(checkBox);
            }
        });
    }

    private String size(){
        if(small.isSelected())
            return "- Small\n";
        if(medium.isSelected())
            return "- Medium\n";
        if(large.isSelected())
            return "- Large\n";
        else
            return "- Party\n";
    }
    private String toppings(){
        String value = "";
        if(topMush.isSelected())
            value+="- Mushroom\n";
        if(topGrPep.isSelected())
            value+="- Green Peppers\n";
        if(topOni.isSelected())
            value+="- Onions\n";
        if(topHotPep.isSelected())
            value+="- Hot Peppers\n";
        if(topPep.isSelected())
            value+="- Pepperoni\n";
        if(topBac.isSelected())
            value+="- Bacon\n";
        if(topToma.isSelected())
            value+="- Tomatoes\n";
        if(topExtraChe.isSelected())
            value+="- Extra Cheese\n";
        return value;
    }
    private String beverages(){
        String count = ""; int i;
        if(cokeBox.getValue()!=null && cokeBox.getValue()!=0){
            i = cokeBox.getValue();
            count+= i+"x Coke\n";
        }
        if(spriteBox.getValue()!=null && spriteBox.getValue()!=0){
            i = spriteBox.getValue();
            count+= i+"x Sprite\n";
        }
        if(orangeBox.getValue()!=null && orangeBox.getValue()!=0){
            i = orangeBox.getValue();
            count+= i+"x Orange\n";
        }
        if(beerBox.getValue()!=null && beerBox.getValue()!=0){
            i = beerBox.getValue();
            count+= i+"x Root Beer\n";
        }
        return count;
    }
}