package com.example.daalgawruud;

import javafx.beans.property.*;

public class CarParts {
    public LongProperty ID;
    public IntegerProperty yr;
    public StringProperty mk;
    public StringProperty mdl;
    public StringProperty cat;
    public StringProperty carName;
    public DoubleProperty price;

    public CarParts() {
    }

    public CarParts(long code, int year, String make, String model, String type, String desc, Double UPrice) {
        ID = new SimpleLongProperty(code);
        yr = new SimpleIntegerProperty(year);
        mk = new SimpleStringProperty(make);
        mdl = new SimpleStringProperty(model);
        cat = new SimpleStringProperty(type);
        carName = new SimpleStringProperty(desc);
        price = new SimpleDoubleProperty(UPrice);
    }


    public long getID() {
        return ID.get();
    }

    public LongProperty IDProperty() {
        return ID;
    }

    public int getYr() {
        return yr.get();
    }

    public IntegerProperty yrProperty() {
        return yr;
    }

    public String getMk() {
        return mk.get();
    }

    public StringProperty mkProperty() {
        return mk;
    }

    public String getMdl() {
        return mdl.get();
    }

    public StringProperty mdlProperty() {
        return mdl;
    }

    public String getCat() {
        return cat.get();
    }

    public StringProperty catProperty() {
        return cat;
    }

    public String getCarName() {
        return carName.get();
    }

    public StringProperty carNameProperty() {
        return carName;
    }

    public double getPrice() {
        return price.get();
    }

    public DoubleProperty priceProperty() {
        return price;
    }

    public void setID(long ID) {
        this.ID.set(ID);
    }

    public void setYr(int yr) {
        this.yr.set(yr);
    }

    public void setMk(String mk) {
        this.mk.set(mk);
    }

    public void setMdl(String mdl) {
        this.mdl.set(mdl);
    }

    public void setCat(String cat) {
        this.cat.set(cat);
    }

    public void setCarName(String carName) {
        this.carName.set(carName);
    }

    public void setPrice(double price) {
        this.price.set(price);
    }

    public String toString(){
        return this.ID +" "+
                this.yr +" "+
                this.mk +" "+
                this.mdl +" "+
                this.cat +" "+
                this.carName +" "+
                this.price;
    }
}
