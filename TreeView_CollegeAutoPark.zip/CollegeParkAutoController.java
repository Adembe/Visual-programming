package com.example.daalgawruud;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Objects;

public class CollegeParkAutoController {
    @FXML
    private TableColumn<CarParts, String> availPartName;

    @FXML
    private TableColumn<CarParts, String> availPartNumber;

    @FXML
    private TableColumn<CarParts, String> availUnitPrice;

    @FXML
    private Button btnClose;

    @FXML
    private Button btnRem1;

    @FXML
    private Button btnRem2;

    @FXML
    private Button btnRem3;

    @FXML
    private Button btnRem4;

    @FXML
    private Button btnRem5;

    @FXML
    private Button btnRem6;

    @FXML
    private TableView<CarParts> colAvailParts;

    @FXML
    private TreeView<String> TreeViewCar;

    @FXML
    private TextField gty1;

    @FXML
    private TextField gty2;

    @FXML
    private TextField gty3;

    @FXML
    private TextField gty4;

    @FXML
    private TextField gty5;

    @FXML
    private TextField gty6;

    @FXML
    private TextField partName1;

    @FXML
    private TextField partName2;

    @FXML
    private TextField partName3;

    @FXML
    private TextField partName4;

    @FXML
    private TextField partName5;

    @FXML
    private TextField partName6;

    @FXML
    private TextField partNumber1;

    @FXML
    private TextField partNumber2;

    @FXML
    private TextField partNumber3;

    @FXML
    private TextField partNumber4;

    @FXML
    private TextField partNumber5;

    @FXML
    private TextField partNumber6;

    @FXML
    private TextField subTotal1;

    @FXML
    private TextField subTotal2;

    @FXML
    private TextField subTotal3;

    @FXML
    private TextField subTotal4;

    @FXML
    private TextField subTotal5;

    @FXML
    private TextField subTotal6;

    @FXML
    private TextField totalOrder;

    @FXML
    private TextField unitPrice1;

    @FXML
    private TextField unitPrice2;

    @FXML
    private TextField unitPrice3;

    @FXML
    private TextField unitPrice4;

    @FXML
    private TextField unitPrice5;

    @FXML
    private TextField unitPrice6;

    boolean[] itemsIndex = {false, false, false, false, false, false, false};
    boolean[] isNull = {false, false, false, false, false, false};
    int i = 0;
    double ttlPrice = 0;
    TreeItem<String> rootItem;
    ArrayList<CarParts> parts;
    ObservableList<TreeItem<String>> items;

    ObservableList<CarParts> treeItem = FXCollections.observableArrayList();

    Image home = new Image(Objects.requireNonNull(getClass().getResourceAsStream("home.png")));
    Image rombo = new Image(Objects.requireNonNull(getClass().getResourceAsStream("rombo.png")));
    Image diamond= new Image(Objects.requireNonNull(getClass().getResourceAsStream("diamond.png")));
    Image car = new Image(Objects.requireNonNull(getClass().getResourceAsStream("car.png")));
    Image paper = new Image(Objects.requireNonNull(getClass().getResourceAsStream("paper.png")));


    @FXML
    void initialize(){
        rootItem = new TreeItem<String> ("College Park Auto-Parts", new ImageView(home));
        items = FXCollections.observableArrayList();
        rootItem.setExpanded(true);
        TreeViewCar.setRoot(rootItem);
        addNodes();
        buildParts();
        subNode();
        addListener();
        dataToField();
        calc();
    }
    @FXML
    void Close(ActionEvent event) {
        Platform.exit();
    }
    @FXML
    void Remove1(ActionEvent event) {
        partNumber1.setText("");
        partName1.setText("");
        unitPrice1.setText("0.00");
        gty1.setText("0");
        subTotal1.setText("0.00");
        itemsIndex[0] = false;
        isNull[0] = false;
        i = 0;
        calc();
    }
    @FXML
    void Remove2(ActionEvent event) {
        partNumber2.setText("");
        partName2.setText("");
        unitPrice2.setText("0.00");
        gty2.setText("0");
        subTotal2.setText("0");
        itemsIndex[1] = false;
        isNull[1] = false;
        i=1;
        calc();
    }
    @FXML
    void Remove3(ActionEvent event) {
        partNumber3.setText("");
        partName3.setText("");
        unitPrice3.setText("0.00");
        gty3.setText("0");
        subTotal3.setText("0");
        itemsIndex[2] = false;
        isNull[2] = false;
        i=2;
        calc();
    }
    @FXML
    void Remove4(ActionEvent event) {
        partNumber4.setText("");
        partName4.setText("");
        unitPrice4.setText("0.00");
        gty4.setText("0");
        subTotal4.setText("0");
        itemsIndex[3] = false;
        isNull[3] = false;
        i=3;
        calc();
    }
    @FXML
    void Remove5(ActionEvent event) {
        partNumber5.setText("");
        partName5.setText("");
        unitPrice5.setText("0.00");
        gty5.setText("0");
        subTotal5.setText("0");
        itemsIndex[4] = false;
        isNull[4] = false;
        i=4;
        calc();
    }
    @FXML
    void Remove6(ActionEvent event) {
        partNumber6.setText("");
        partName6.setText("");
        unitPrice6.setText("0.00");
        gty6.setText("0");
        subTotal6.setText("0");
        itemsIndex[5] = false;
        isNull[5] = false;
        i=5;
        calc();
    }

    void addNodes(){
        for(int i=2022; i>=1960; i--){
            items.add(new TreeItem<String>("" + i, new ImageView(rombo)));
        }
        rootItem.getChildren().addAll(items);
    }
    void buildParts(){
        parts = new ArrayList<>();
        parts.add(new CarParts(447093, 2002, "Ford",
                "Escort SE L4 2.0", "Engine Electrical",
                "Alternator 75amp  Remanufactured; w/ 75 Amp",
                205.05));
        parts.add(new CarParts(203815, 2006, "Dodge",
                "Caravan SE L4 2.4", "Cooling System",
                "Radiator Cap", 6.65));
        parts.add(new CarParts(293047, 2000, "Toyota",
                "RAV4 2WD/4-DOOR", "Cooling System",
                "Thermostat Gasket", 4.95));
        parts.add(new CarParts(990468, 2002, "Honda",
                "Civic 1.7 EX 4DR", "Exhaust",
                "Bolt & Spring Kit (Manifold outlet, Muffler Inlet)",
                85.75));
        parts.add(new CarParts(304158, 1996, "Buick",
                "Regal Custom V6 3.8", "Fuel Injection",
                "Fuel Injector", 82.75));
        parts.add(new CarParts(807245, 2004, "Acura",
                "MDX 3.5 4WD", "Driveshaft & Axle",
                "CV Boot Clamp 7 x 750mm; 1 Large + 1 Small Clamp",
                1.60));
        parts.add(new CarParts(203485, 2001, "Ford",
                "Taurus LX V6 3.0", "Fuel Injection",
                "Oxygen Sensor OE Style 4Wire; Front; 2 Required",
                52.65));
        parts.add(new CarParts(248759, 1999, "Jeep",
                "Wrangler Sahara", "Air Intake",
                "Air Filter AirSoft Panel", 7.95));
        parts.add(new CarParts(202848, 1998, "Honda",
                "Accord 2.3 LX 4DR", "Air Intake",
                "Air Filter", 12.55));
        parts.add(new CarParts(932759, 2006, "Kia",
                "Rio 1.6DOHC16V 4-DR", "Cooling System",
                "Thermostat", 14.45));
        parts.add(new CarParts(304975, 2000, "Honda",
                "Civic 1.6 EX 4DR", "Suspension",
                "Ball Joint; Front Lower; 2 per car", 40.55));
        parts.add(new CarParts(208450, 2003, "Chevrolet",
                "Monte Carlo LS V6 3.4", "Fuel Injection",
                "Oxygen Sensor OE connector; Rear", 65.55));
        parts.add(new CarParts(209480, 2002, "Ford",
                "Focus SE DOHC L4 2.0", "Steering",
                "Steering Rack Remanufactured", 170.85));
        parts.add(new CarParts(203495, 2004, "Honda",
                "Civic 1.7 EX 4DR", "Climate Control",
                "A/C Clutch; OE compressor = Sanden", 184.95));
        parts.add(new CarParts(203480, 2007, "Toyota",
                "Corolla", "Air Intake",
                "Air Filter", 12.65));
        parts.add(new CarParts(109379, 2005, "Volvo",
                "S40 2.5L T5 AWD", "Fuel Delivery",
                "Fuel Filter; Early Design; Outer Diameter = 55mm",
                30.95));
        parts.add(new CarParts(935794, 2002, "Ford",
                "Escape XLS 4WD", "Brake",
                "Brake Caliper Remanufactured; Front Right",
                65.55));
        parts.add(new CarParts(203485, 2006, "BMW",
                "325i", "Climate Control",
                "AC High Pressure Side Switch",
                49.95));
        parts.add(new CarParts(204875, 1996, "Chevrolet",
                "Monte Carlo Z34 V6 3.4", "Fuel Delivery",
                "Fuel Filter", 8.05));
        parts.add(new CarParts(937485, 2010, "Toyota",
                "Camry V6", "Air Intake", "Air Filter", 12.95));
        parts.add(new CarParts(294759, 2001, "Ford",
                "Escape XLT 4WD", "Air Intake",
                "Air Filter Panel", 7.25));
        parts.add(new CarParts(297495, 2003, "Honda",
                "Civic 1.7 EX 4DR", "Brake",
                "Brake Caliper Reman; w/ ProAct Pads; Front Right",
                82.55));
        parts.add(new CarParts(794735, 2006, "BMW",
                "325i", "Climate Control",
                "Cabin Air/Pollen Filter; With Activated Carbon",
                28.05));
        parts.add(new CarParts(937485, 2011, "Toyota",
                "Corolla", "Body Electrical",
                "Halogen  SilverStar; 12V 65W; inner-high beam",
                22.85));
        parts.add(new CarParts(492745, 2005, "Ford",
                "Focus ZX3 L4 2.0", "Air Intake",
                "Fuel Injection Perf Kit", 342.95));
        parts.add(new CarParts(937005, 2004, "Acura",
                "MDX 3.5 4WD", "Driveshaft & Axle",
                "CV Boot Clamp 7 x 750mm; For Large End of Boot; inner boot",
                1.60));
        parts.add(new CarParts(293749, 2004, "Acura",
                "MDX 3.5 4WD", "Driveshaft & Axle",
                "Axle Nut 24mm x 1;5; rear ",
                2.35));
        parts.add(new CarParts(920495, 2006, "BMW",
                "325i", "Climate Control",
                "Adjustable Telescoping Mirror", 7.95));
        parts.add(new CarParts(204075, 2004, "Acura",
                "MDX 3.5 4WD", "Driveshaft & Axle",
                "Wheel Bearing; Rear; 1 per wheel",
                70.15));
        parts.add(new CarParts(979304, 2000, "Toyota",
                "RAV4 2WD/4-DOOR", "Cooling System",
                "Thermostat Housing", 20.95));
        parts.add(new CarParts(300456, 2004, "Acura",
                "MDX 3.5 4WD", "Driveshaft & Axle",
                "Wheel Bearing; Front; 1 per wheel",
                66.65));
        parts.add(new CarParts(404860, 2001, "Ford",
                "Taurus LX V6 3.0", "Suspension",
                "Shock Absorber GR2; Rear; Wagon only",
                39.40));
        parts.add(new CarParts(585688, 2012, "Buick",
                "Lacrosse CXS V6 3.6", "Brake",
                "Climate Control", 10.65));
        parts.add(new CarParts(739759, 2001, "Ford",
                "Taurus LX V6 3.0", "Suspension",
                "Shock Absorber GasaJust; Rear; Wagon only",
                30.95));
        parts.add(new CarParts(927495, 2005, "Volvo",
                "S40 2.5L T5 AWD", "Engine Mechanical",
                "Timing Belt Idler Pulley Original Equipment INA",
                65.55));
        parts.add(new CarParts(979374, 2000, "Toyota",
                "RAV4 2WD/4-DOOR", "Cooling System",
                "Thermostat Gasket", 4.95));
        parts.add(new CarParts(542347, 2013, "Buick",
                "Lacrosse CXS V6 3.6", "Brake",
                "Brake Pad Set ProACT Ceramic w/Shims; Front", 80.05));
        parts.add(new CarParts(683064, 2000, "Toyota",
                "RAV4 2WD/4-DOOR", "Cooling System",
                "Radiator Hose; Upper", 103.75));
        parts.add(new CarParts(248759, 1999, "Jeep",
                "Wrangler Sahara", "Air Intake",
                "Air Filter", 50.95));
        parts.add(new CarParts(973974, 2014, "Toyota",
                "Corolla", "Air Intake",
                "Air Mass Meter; W/o Housing; Meter/sensor only",
                134.95));
        parts.add(new CarParts(285800, 2001, "Ford",
                "Escape XLT 4WD", "Transmission",
                "AT Filter", 34.95));
        parts.add(new CarParts(207495, 2015, "Toyota",
                "Corolla", "Body Electrical",
                "Headlight Bulb; 12V 65W; inner-high beam", 9.35));
        parts.add(new CarParts(566676, 2000, "Toyota",
                "RAV4 2WD/4-DOOR", "Cooling System",
                "Auxiliary Fan Switch", 42.95));
        parts.add(new CarParts(304950, 2016, "Toyota",
                "Corolla", "Body Electrical",
                "Headlight Bulb; 12V 51W; outer", 7.85));
        parts.add(new CarParts(797394, 2000, "Toyota",
                "RAV4 2WD/4-DOOR", "Cooling System",
                "Water Flange Gasket", 0.85));
        parts.add(new CarParts(910203, 2017, "Buick",
                "Lacrosse CXS V6 3.6", "Suspension",
                "Strut Mount Inc; Sleeve; Rear Right", 80.85));
        parts.add(new CarParts(790794, 2000, "Toyota",
                "RAV4 2WD/4-DOOR", "Cooling System",
                "Radiator Hose; Lower", 9.45));
        parts.add(new CarParts(970394, 2018, "Buick",
                "Lacrosse CXS V6 3.6", "Suspension",
                "Coil Spring Insulator; Front Lower",
                14.55));
        parts.add(new CarParts(290840, 2005, "Volvo",
                "S40 2.5L T5 AWD", "Engine Mechanical",
                "Rod Bearing Set 1 per Rod; Standard; Reqs. 5-per Engine",
                26.95));
        parts.add(new CarParts(209704, 2019, "Toyota",
                "Corolla", "Body Electrical",
                "Wiper Blade Excel+; Front Right", 7.25));
        parts.add(new CarParts(200368, 2000, "Toyota",
                "RAV4 2WD/4-DOOR", "Cooling System",
                "Radiator Drain Plug incl; gasket", 3.15));
        parts.add(new CarParts(200970, 2005, "Volvo",
                "S40 2.5L T5 AWD", "Engine Mechanical",
                "Reference Sensor; Flywheel Engine Speed",
                62.05));
        parts.add(new CarParts(542347, 2020, "Buick",
                "Lacrosse CXS V6 3.6", "Air Intake",
                "Air Filter", 50.25));
        parts.add(new CarParts(927045, 2001, "Ford",
                "Escape XLT 4WD", "Air Intake",
                "Air Filter", 62.95));
        parts.add(new CarParts(990659, 2021, "Toyota",
                "RAV4 2WD/4-DOOR", "Cooling System",
                "Radiator OE Plastic tank", 136.85));
        parts.add(new CarParts(440574, 2022, "Buick",
                "Lacrosse CXS V6 3.6", "Suspension",
                "Strut Mount Inc; Sleeve; Rear Left",
                80.80));
    }
    void subNode(){
        for (CarParts p : parts) {
            for (TreeItem<String> t: items){
                if(p.getYr() == Integer.parseInt(t.getValue())){
                    TreeItem<String> make = new TreeItem<>(p.getMk(), new ImageView(diamond));
                    TreeItem<String> model = new TreeItem<>(p.getMdl(), new ImageView(car));
                    TreeItem<String> type = new TreeItem<>(p.getCat(), new ImageView(paper));
                    make.getChildren().add(model);
                    model.getChildren().add(type);
                    t.getChildren().add(make);
                }
            }
        }
    }
    void addListener(){
        TreeViewCar.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if(mouseEvent.getClickCount() ==  2){
                    TreeItem<String> element = TreeViewCar.getSelectionModel().getSelectedItem();
                    try {
                        String nodeYear = element.getParent().getParent().getParent().getValue();
                        String nodeMake = element.getParent().getParent().getValue();
                        String nodeModel = element.getParent().getValue();
                        for(CarParts part : parts) {
                            if((Integer.parseInt(nodeYear) == part.getYr()) && nodeMake.equals(part.getMk()) && nodeModel.equals(part.getMdl())) {
                                treeItem.add(part);
                                availPartNumber.setCellValueFactory(new PropertyValueFactory<>("ID"));
                                availPartName.setCellValueFactory(new PropertyValueFactory<>("carName"));
                                availUnitPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
                                colAvailParts.setItems(treeItem);
                                System.out.println(treeItem);
                            }
                        }
                    }
                    catch (Exception e){
                        System.out.println("Error: " + e.getMessage());
                    }
                }

            }
        });
    }
    void dataToField(){
        colAvailParts.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent mouseEvent) {
                if(mouseEvent.getClickCount() == 2) {
                    System.out.println(colAvailParts.getSelectionModel().getSelectedItem().getID());
                    String itemID = colAvailParts.getSelectionModel().getSelectedItem().getID() + "";
                    String itemName = colAvailParts.getSelectionModel().getSelectedItem().getCarName();
                    String itemPrice = colAvailParts.getSelectionModel().getSelectedItem().getPrice() + "";
                    itemsIndex[i] = true;
                    if(i < 6) {
                        i++;
                    }
                    if(itemsIndex[0] && !isNull[0]) {
                        partNumber1.setText(itemID);
                        partName1.setText(itemName);
                        unitPrice1.setText(itemPrice);
                        itemsIndex[0] = false;
                        isNull[0] = true;
                    }
                    if(itemsIndex[1] && !isNull[1]) {
                        partNumber2.setText(itemID);
                        partName2.setText(itemName);
                        unitPrice2.setText(itemPrice);
                        itemsIndex[1] = false;
                        isNull[1] = true;
                    }
                    if(itemsIndex[2] && !isNull[2]) {
                        partNumber3.setText(itemID);
                        partName3.setText(itemName);
                        unitPrice3.setText(itemPrice);
                        itemsIndex[2] = false;
                        isNull[2] = true;
                    }
                    if(itemsIndex[3] && !isNull[3]) {
                        partNumber4.setText(itemID);
                        partName4.setText(itemName);
                        unitPrice4.setText(itemPrice);
                        itemsIndex[3] = false;
                        isNull[3] = true;
                    }
                    if(itemsIndex[4] && !isNull[4]) {
                        partNumber5.setText(itemID);
                        partName5.setText(itemName);
                        unitPrice5.setText(itemPrice);
                        itemsIndex[4] = false;
                        isNull[4] = true;
                    }
                    if(itemsIndex[5] && !isNull[5]) {
                        partNumber6.setText(itemID);
                        partName6.setText(itemName);
                        unitPrice6.setText(itemPrice);
                        itemsIndex[5] = false;
                        isNull[5] = true;
                    }
                }
            }
        });

    }
    void calc(){
        try {
            NumberFormat formatter = new DecimalFormat("0.00");

            gty1.textProperty().addListener((observable, oldValue, newValue) -> {
                ttlPrice = ttlPrice + Integer.parseInt(gty1.getText()) * Double.parseDouble(unitPrice1.getText());
                subTotal1.setText(formatter.format(Integer.parseInt(gty1.getText()) * Double.parseDouble(unitPrice1.getText())) + "");
                totalOrder.setText(formatter.format(ttlPrice) + "");
            });
            gty2.textProperty().addListener((observable, oldValue, newValue) -> {
                ttlPrice += Integer.parseInt(gty2.getText()) * Double.parseDouble(unitPrice2.getText());
                subTotal2.setText(formatter.format(Integer.parseInt(gty2.getText()) * Double.parseDouble(unitPrice2.getText())) + "");
                totalOrder.setText(formatter.format(ttlPrice) + "");
            });
            gty3.textProperty().addListener((observable, oldValue, newValue) -> {
                ttlPrice += Integer.parseInt(gty3.getText()) * Double.parseDouble(unitPrice3.getText());
                subTotal3.setText(formatter.format(Integer.parseInt(gty3.getText()) * Double.parseDouble(unitPrice3.getText())) + "");
                totalOrder.setText(formatter.format(ttlPrice) + "");
            });
            gty4.textProperty().addListener((observable, oldValue, newValue) -> {
                ttlPrice += Integer.parseInt(gty4.getText()) * Double.parseDouble(unitPrice4.getText());
                subTotal4.setText(formatter.format(Integer.parseInt(gty4.getText()) * Double.parseDouble(unitPrice4.getText())) + "");
                totalOrder.setText(formatter.format(ttlPrice) + "");
            });
            gty5.textProperty().addListener((observable, oldValue, newValue) -> {
                ttlPrice += Integer.parseInt(gty5.getText()) * Double.parseDouble(unitPrice5.getText());
                subTotal5.setText(formatter.format(Integer.parseInt(gty5.getText()) * Double.parseDouble(unitPrice5.getText())) + "");
                totalOrder.setText(formatter.format(ttlPrice) + "");
            });
            gty6.textProperty().addListener((observable, oldValue, newValue) -> {
                ttlPrice += Integer.parseInt(gty6.getText()) * Double.parseDouble(unitPrice6.getText());
                subTotal6.setText(formatter.format(Integer.parseInt(gty6.getText()) * Double.parseDouble(unitPrice6.getText())) + "");
                totalOrder.setText(formatter.format(ttlPrice) + "");
            });
        }
        catch(Exception e) {
            System.out.println("Хэдэн ширхэг авахаа заавал оруулна уу!: " + e.getMessage());
        }
    }
}
