package com.example.daalgawruud;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class CarPartsModel {
    public IntegerProperty partNumber;
    public StringProperty partName;
    public IntegerProperty unitPrice;

    public CarPartsModel(int pNumber, String pName, int pPrice) {
        partNumber = new SimpleIntegerProperty(pNumber);
        partName = new SimpleStringProperty(pName);
        unitPrice = new SimpleIntegerProperty(pPrice);
    }

    public int getPartNumber() {
        return partNumber.get();
    }

    public IntegerProperty partNumberProperty() {
        return partNumber;
    }

    public String getPartName() {
        return partName.get();
    }

    public StringProperty partNameProperty() {
        return partName;
    }

    public int getUnitPrice() {
        return unitPrice.get();
    }

    public IntegerProperty unitPriceProperty() {
        return unitPrice;
    }

    public void setPartNumber(int partNumber) {
        this.partNumber.set(partNumber);
    }

    public void setPartName(String partName) {
        this.partName.set(partName);
    }

    public void setUnitPrice(int unitPrice) {
        this.unitPrice.set(unitPrice);
    }
}
