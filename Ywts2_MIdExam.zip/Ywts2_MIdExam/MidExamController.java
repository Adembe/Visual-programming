package com.example.daalgawruud;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.util.Callback;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;
public class MidExamController {
    Callback<TableColumn<Person,Date>, TableCell<Person, Date>> date = (TableColumn<Person, Date> param) -> new EditingDatePickerCell();
    @FXML
    private TableColumn<Person, Date> colBirthDate;

    @FXML
    private TableColumn<Person, HBox> colCountry;

    @FXML
    private TableColumn<Person, String> colFullName;

    @FXML
    private TableColumn<Person, ImageView> colGroupName;

    @FXML
    private TableColumn<Person, String> colJobTitle;

    @FXML
    private TableColumn<Person, String> colPhone;

    @FXML
    private TableView<Person> tableView;

    Image male = new Image(Objects.requireNonNull(getClass().getResourceAsStream("male.png")));
    Image female = new Image(Objects.requireNonNull(getClass().getResourceAsStream("female.png")));
    Image notifi = new Image(Objects.requireNonNull(getClass().getResourceAsStream("notifi.png")));
    Image phone = new Image(Objects.requireNonNull(getClass().getResourceAsStream("phone.png")));
    Image list = new Image(Objects.requireNonNull(getClass().getResourceAsStream("list.png")));
    Image country = new Image(Objects.requireNonNull(getClass().getResourceAsStream("country.png")));
    Image user = new Image(Objects.requireNonNull(getClass().getResourceAsStream("user.png")));
    ArrayList<Person> arr = new ArrayList<>();
    @FXML
    void initialize(){
        DatabaseConnection();

        show();

    }

    public void DatabaseConnection(){
        DataBaseConnect connectNow = new DataBaseConnect();
        Connection connectDB = connectNow.getConnection();
        String getInfo = "SELECT * FROM people";
        try {
            Statement statement = connectDB.createStatement();
            ResultSet queryResult = statement.executeQuery(getInfo);
            while (queryResult.next()) {
                ImageView img = new ImageView(male);
                Person people = new Person();
                people.setGender(new ImageView(queryResult.getObject(2).toString().equalsIgnoreCase("male") ? male:female));
                people.setFullName(queryResult.getObject(3).toString());
                people.setBirthDate((Date) queryResult.getObject(4));
                people.setJobTitle(queryResult.getObject(5).toString());
                people.setPhone(queryResult.getObject(7).toString());
                HBox box = new HBox();
                ImageView img1 = new ImageView(Equal(queryResult.getObject(6).toString()));
                box.setSpacing(10);
                Label lb = new Label(queryResult.getObject(6).toString());
                box.getChildren().addAll(img1,lb);
                people.setCountry(box);
                arr.add(people);
            }
        } catch (Exception e) {
            e.printStackTrace();
            e.getCause();
        }
    }

    public void show() {

        ObservableList<Person> obList = FXCollections.observableArrayList(arr);
        tableView.setEditable(true);

        colGroupName.setCellValueFactory(new PropertyValueFactory<>("gender"));
        colFullName.setCellValueFactory(new PropertyValueFactory<>("fullName"));
        colFullName.setGraphic(new ImageView(list));
        colBirthDate.setCellValueFactory(new PropertyValueFactory<Person, Date>("birthDate"));
        colBirthDate.setCellFactory(date);
        colBirthDate.setGraphic(new ImageView(notifi));
        colJobTitle.setCellValueFactory(new PropertyValueFactory<>("jobTitle"));
        colJobTitle.setGraphic(new ImageView(user));
        colCountry.setCellValueFactory(new PropertyValueFactory<>("country"));
        colCountry.setGraphic(new ImageView(country));
        colPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
        colPhone.setGraphic(new ImageView(phone));
        tableView.setItems(obList);
    }

    public Image Equal(String country){
        String zam = country+".png";
        Image obj = new Image(Objects.requireNonNull(getClass().getResourceAsStream(zam)));
        return obj;
    }
}