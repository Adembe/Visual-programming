package com.example.daalgawruud;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;

import java.time.LocalDate;
import java.util.Date;

public class Person {
    private ImageView gender;
    private String fullName;
    private Date birthDate;
    private String jobTitle;
    private HBox country;
    private String phone;

    public Person() {
    }

    public Person(ImageView gender, String fullName, Date birthDate, String jobTitle, HBox country, String phone) {
        this.gender = gender;
        this.fullName = fullName;
        this.birthDate = birthDate;
        this.jobTitle = jobTitle;
        this.country = country;
        this.phone = phone;
    }

    public ImageView isGender() {
        return gender;
    }

    public String getFullName() {
        return fullName;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public HBox getCountry() {
        return country;
    }

    public String getPhone() {
        return phone;
    }

    public HBox box;

    public void setGender(ImageView gender) {
        this.gender = gender;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public void setCountry(HBox country) {
        this.country = country;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
